from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
import pandas as pd
import numpy as np
import joblib
import os
from datetime import datetime, timedelta
import random

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Load the model and encoder
model = joblib.load("models/flood_best_model.pkl")
label_encoder = joblib.load("models/label_encoder.pkl")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/static/<path:path>')
def send_static(path):
    return send_from_directory('static', path)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get data from request
        data = request.get_json()
        
        # Extract and transform the data to match model expectations
        input_features = {
            'rainfall': float(data.get('rainfall', 0)),
            'river_level': float(data.get('riverLevel', 0)),
            'soil_moisture': float(data.get('soilMoisture', 0)),
            'temperature': float(data.get('temperature', 0)),
            'humidity': float(data.get('humidity', 0)),
            # Note: The model might not use location and date, but we'll include them if needed
        }
        
        # Convert to DataFrame with correct column names (adjust based on your model's training features)
        # You might need to map frontend field names to your model's feature names
        input_data = pd.DataFrame([input_features])
        
        # Make prediction
        prediction_encoded = model.predict(input_data)[0]
        probabilities = model.predict_proba(input_data)[0]
        
        # Decode prediction
        prediction = label_encoder.inverse_transform([prediction_encoded])[0]
        
        # Create response
        response = {
            'prediction': prediction,
            'probabilities': {
                'LOW': float(probabilities[0]),
                'MEDIUM': float(probabilities[1]),
                'HIGH': float(probabilities[2])
            }
        }
        
        return jsonify(response)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/batch_predict', methods=['POST'])
def batch_predict():
    try:
        # Get data from request
        data = request.get_json()
        
        # Convert to DataFrame
        input_data = pd.DataFrame(data)
        
        # Make predictions
        predictions_encoded = model.predict(input_data)
        probabilities = model.predict_proba(input_data)
        
        # Decode predictions
        predictions = label_encoder.inverse_transform(predictions_encoded)
        
        # Create response
        results = []
        for i, pred in enumerate(predictions):
            results.append({
                'prediction': pred,
                'probabilities': {
                    'LOW': float(probabilities[i][0]),
                    'MEDIUM': float(probabilities[i][1]),
                    'HIGH': float(probabilities[i][2])
                }
            })
        
        return jsonify(results)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400

# Additional endpoints to support the frontend
@app.route('/api/dashboard-data')
def dashboard_data():
    """Endpoint to provide data for the dashboard"""
    # Generate some sample data for demonstration
    current_risk = random.choice(['LOW', 'MEDIUM', 'HIGH'])
    rainfall = round(random.uniform(10, 100), 1)
    river_level = round(random.uniform(1.5, 4.5), 1)
    
    # Generate trend data
    months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    risk_trend = [random.randint(20, 80) for _ in range(12)]
    
    # Generate recent predictions
    locations = ['Northern Region', 'Eastern District', 'Southern Plains', 'Western Valley']
    recent_predictions = []
    for i in range(4):
        recent_predictions.append({
            'location': locations[i],
            'time': (datetime.now() - timedelta(hours=i)).strftime('%I:%M %p'),
            'risk': random.choice(['LOW', 'MEDIUM', 'HIGH'])
        })
    
    return jsonify({
        'current_risk': current_risk,
        'rainfall': rainfall,
        'river_level': river_level,
        'risk_trend': risk_trend,
        'months': months,
        'recent_predictions': recent_predictions
    })

@app.route('/api/alert-data')
def alert_data():
    """Endpoint to provide alert data"""
    alerts = [
        {
            'type': 'danger',
            'title': 'High Flood Warning',
            'region': 'Northern Region',
            'time': '10 min ago',
            'message': 'Northern region has 85% flood risk in next 24 hours',
            'details': 'River levels expected to exceed flood stage by 1.2 meters.'
        },
        {
            'type': 'warning',
            'title': 'Moderate Flood Alert',
            'region': 'Eastern District',
            'time': '1 hour ago',
            'message': 'River levels rising in eastern districts',
            'details': 'Current level: 3.4m, Flood stage: 4.0m'
        },
        {
            'type': 'info',
            'title': 'Heavy Rainfall Advisory',
            'region': 'Western Region',
            'time': '2 hours ago',
            'message': 'Heavy rainfall expected in western areas',
            'details': 'Expected rainfall: 60-80mm in next 12 hours'
        }
    ]
    
    stats = {
        'high_priority': random.randint(1, 5),
        'medium_priority': random.randint(3, 8),
        'low_priority': random.randint(5, 15)
    }
    
    return jsonify({
        'alerts': alerts,
        'stats': stats
    })

@app.route('/api/trends-data')
def trends_data():
    """Endpoint to provide trends data"""
    months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    
    # Rainfall data
    rainfall_data = [random.randint(20, 130) for _ in range(12)]
    
    # River level data
    river_level_data = [round(random.uniform(1.5, 5.0), 1) for _ in range(12)]
    
    # Flood events data
    flood_events = [random.randint(0, 5) for _ in range(6)]
    flood_years = ['2018', '2019', '2020', '2021', '2022', '2023']
    
    return jsonify({
        'months': months,
        'rainfall_data': rainfall_data,
        'river_level_data': river_level_data,
        'flood_events': flood_events,
        'flood_years': flood_years
    })

if __name__ == '__main__':
    # Create static directory if it doesn't exist
    if not os.path.exists('static'):
        os.makedirs('static')
        
    app.run(debug=True, host='0.0.0.0', port=5000)