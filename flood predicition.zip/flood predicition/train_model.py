import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from sklearn.pipeline import Pipeline
import joblib
import os
import shap
from imblearn.over_sampling import SMOTE
from sklearn.utils import class_weight

# Create models directory first
os.makedirs("models", exist_ok=True)

# Set style for visualizations
plt.style.use('default')
sns.set_palette("husl")

# Load dataset
df = pd.read_csv("flood.csv")

# Check the distribution of FloodProbability to set appropriate thresholds
print("FloodProbability distribution:")
print(df["FloodProbability"].describe())

# Use quantile-based thresholds for more balanced classes
low_threshold = df["FloodProbability"].quantile(0.33)
high_threshold = df["FloodProbability"].quantile(0.66)

print(f"Using thresholds: LOW < {low_threshold:.3f}, MEDIUM < {high_threshold:.3f}, HIGH >= {high_threshold:.3f}")

# Convert probability to three risk categories using quantile-based thresholds
df["RiskLevel"] = pd.cut(df["FloodProbability"], 
                         bins=[0, low_threshold, high_threshold, 1], 
                         labels=["LOW", "MEDIUM", "HIGH"], 
                         include_lowest=True)

# Check class distribution
print("Risk level distribution:")
class_distribution = df["RiskLevel"].value_counts()
print(class_distribution)

# Check if we have severe class imbalance
if class_distribution.min() / class_distribution.max() < 0.1:
    print("Severe class imbalance detected. Applying SMOTE...")
    apply_smote = True
else:
    apply_smote = False

X = df.drop(columns=["FloodProbability", "RiskLevel"])
y = df["RiskLevel"]

# Encode string labels to integers for XGBoost and LightGBM
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)

# Split data into train and test sets with stratification
X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded)

# Apply SMOTE if severe class imbalance
if apply_smote:
    print("Applying SMOTE to balance classes...")
    smote = SMOTE(random_state=42)
    X_train, y_train = smote.fit_resample(X_train, y_train)
    print("New class distribution after SMOTE:", np.bincount(y_train))

# Calculate class weights to handle imbalance
class_weights = class_weight.compute_class_weight('balanced', classes=np.unique(y_train), y=y_train)
class_weight_dict = dict(zip(np.unique(y_train), class_weights))

print("Class weights:", class_weight_dict)

# Define models and parameters with adjusted parameters for LightGBM
models = {
    "RandomForest": {
        "model": RandomForestClassifier(class_weight=class_weight_dict, random_state=42),
        "params": {
            "model__n_estimators": [100, 200],
            "model__max_depth": [4, 6, None],
            "model__min_samples_split": [2, 5]
        }
    },
    "XGBoost": {
        "model": XGBClassifier(use_label_encoder=False, eval_metric="logloss", random_state=42),
        "params": {
            "model__n_estimators": [100, 200],
            "model__max_depth": [4, 6],
            "model__learning_rate": [0.1, 0.2]
        }
    },
    "LightGBM": {
        "model": LGBMClassifier(
            random_state=42,
            min_child_samples=20,  # Increased from default to prevent overfitting
            reg_alpha=0.1,         # Added L1 regularization
            reg_lambda=0.1         # Added L2 regularization
        ),
        "params": {
            "model__n_estimators": [100, 200],
            "model__max_depth": [3, 4],  # Reduced max depth
            "model__learning_rate": [0.05, 0.1],  # Reduced learning rate
            "model__num_leaves": [31, 63]  # Added num_leaves parameter
        }
    }
}

# Train and evaluate models
best_accuracy = 0
best_model = None
best_model_name = ""

for name, model_info in models.items():
    print(f"\nTraining {name} model...")
    
    # Create pipeline
    pipe = Pipeline([
        ("scaler", StandardScaler()),
        ("model", model_info["model"])
    ])
    
    # Grid search
    grid = GridSearchCV(pipe, model_info["params"], cv=3, scoring="accuracy", verbose=1)
    grid.fit(X_train, y_train)
    
    # Predictions
    y_pred = grid.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    
    print(f"{name} Best Parameters: {grid.best_params_}")
    print(f"{name} Accuracy: {round(accuracy, 4)}")
    
    # Convert back to string labels for reporting
    y_test_str = label_encoder.inverse_transform(y_test)
    y_pred_str = label_encoder.inverse_transform(y_pred)
    
    print("Classification Report:")
    print(classification_report(y_test_str, y_pred_str, zero_division=0))
    
    # Check if this is the best model
    if accuracy > best_accuracy:
        best_accuracy = accuracy
        best_model = grid.best_estimator_
        best_model_name = name
    
    # Confusion Matrix Heatmap
    plt.figure(figsize=(8, 6))
    cm = confusion_matrix(y_test_str, y_pred_str, labels=["LOW", "MEDIUM", "HIGH"])
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=["LOW", "MEDIUM", "HIGH"], 
                yticklabels=["LOW", "MEDIUM", "HIGH"])
    plt.title(f'{name} Confusion Matrix')
    plt.ylabel('Actual')
    plt.xlabel('Predicted')
    plt.tight_layout()
    plt.savefig(f"models/{name}_confusion_matrix.png", dpi=300)
    plt.close()
    
    # Classification Report Heatmap
    plt.figure(figsize=(8, 6))
    report = classification_report(y_test_str, y_pred_str, output_dict=True, zero_division=0)
    report_df = pd.DataFrame(report).iloc[:-1, :].T
    sns.heatmap(report_df, annot=True, cmap='RdYlGn', center=0.5)
    plt.title(f'{name} Classification Report')
    plt.tight_layout()
    plt.savefig(f"models/{name}_classification_report.png", dpi=300)
    plt.close()

print(f"\nBest model is {best_model_name} with accuracy {round(best_accuracy, 4)}")

# Feature Importance Plot
if hasattr(best_model.named_steps['model'], 'feature_importances_'):
    plt.figure(figsize=(10, 8))
    feature_importance = best_model.named_steps['model'].feature_importances_
    feature_names = X.columns
    indices = np.argsort(feature_importance)[::-1]
    
    plt.barh(range(len(indices)), feature_importance[indices], color='b', align='center')
    plt.yticks(range(len(indices)), [feature_names[i] for i in indices])
    plt.xlabel('Relative Importance')
    plt.title(f'{best_model_name} Feature Importance')
    plt.tight_layout()
    plt.savefig("models/feature_importance.png", dpi=300)
    plt.close()

# SHAP Values for explainability (only if we have a tree-based model)
try:
    # Extract the model from the pipeline
    model_for_shap = best_model.named_steps['model']
    
    # Preprocess data for SHAP
    X_train_preprocessed = best_model.named_steps['scaler'].transform(X_train)
    
    # Create explainer
    explainer = shap.TreeExplainer(model_for_shap)
    shap_values = explainer.shap_values(X_train_preprocessed)
    
    # Summary plot
    plt.figure(figsize=(10, 8))
    shap.summary_plot(shap_values, X_train_preprocessed, feature_names=X.columns, 
                      class_names=label_encoder.classes_, show=False)
    plt.title('SHAP Summary Plot')
    plt.tight_layout()
    plt.savefig("models/shap_summary.png", dpi=300)
    plt.close()
    
except Exception as e:
    print(f"Could not generate SHAP plots: {e}")

# Risk Distribution Visualization
plt.figure(figsize=(10, 6))
y_pred_all = best_model.predict(X)
y_pred_all_str = label_encoder.inverse_transform(y_pred_all)
risk_counts = pd.Series(y_pred_all_str).value_counts().sort_index()
colors = ['green', 'orange', 'red']
risk_counts.plot(kind='bar', color=colors)
plt.title('Predicted Risk Distribution')
plt.xlabel('Risk Level')
plt.ylabel('Count')
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig("models/risk_distribution.png", dpi=300)
plt.close()

# Gauge Chart for a single prediction
def create_gauge_chart(prediction, probabilities, save_path="models/gauge_chart.png"):
    risk_levels = ["LOW", "MEDIUM", "HIGH"]
    colors = ['#00FF00', '#FFFF00', '#FF0000']
    
    fig, ax = plt.subplots(figsize=(8, 8))
    
    # Create gauge background
    angles = np.linspace(0, np.pi, 100)
    ax.plot(np.cos(angles), np.sin(angles), color='black', linewidth=2)
    
    # Fill the gauge with risk colors
    for i, (color, risk) in enumerate(zip(colors, risk_levels)):
        start_angle = i * (np.pi/3)
        end_angle = (i+1) * (np.pi/3)
        angles = np.linspace(start_angle, end_angle, 50)
        x = np.cos(angles) * 0.9
        y = np.sin(angles) * 0.9
        ax.fill_betweenx(y, 0, x, color=color, alpha=0.7)
    
    # Add needle
    risk_index = list(risk_levels).index(prediction)
    needle_angle = risk_index * (np.pi/3) + (np.pi/6)
    needle_length = 0.8
    ax.plot([0, needle_length * np.cos(needle_angle)], 
            [0, needle_length * np.sin(needle_angle)], 
            color='black', linewidth=3)
    
    # Add risk labels
    for i, risk in enumerate(risk_levels):
        angle = i * (np.pi/3) + (np.pi/6)
        x = 1.05 * np.cos(angle)
        y = 1.05 * np.sin(angle)
        ax.text(x, y, risk, ha='center', va='center', fontsize=14, fontweight='bold')
    
    # Add probability text
    ax.text(0, -0.2, f"Predicted: {prediction}\n"
             f"Probabilities: LOW={probabilities[0]:.2f}, "
             f"MEDIUM={probabilities[1]:.2f}, "
             f"HIGH={probabilities[2]:.2f}", 
             ha='center', va='center', fontsize=12, 
             bbox=dict(facecolor='white', alpha=0.8))
    
    ax.set_xlim(-1.2, 1.2)
    ax.set_ylim(-0.2, 1.2)
    ax.axis('off')
    plt.title('Flood Risk Prediction Gauge', fontsize=16)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300)
    plt.close()

# Create gauge chart for a random test sample
if len(X_test) > 0:
    random_index = np.random.randint(0, len(X_test))
    sample = X_test.iloc[random_index:random_index+1]
    prediction_encoded = best_model.predict(sample)[0]
    prediction = label_encoder.inverse_transform([prediction_encoded])[0]
    probabilities = best_model.predict_proba(sample)[0]
    create_gauge_chart(prediction, probabilities)
else:
    print("No test samples available for gauge chart")

# Save the best model and label encoder
joblib.dump(best_model, "models/flood_best_model.pkl")
joblib.dump(label_encoder, "models/label_encoder.pkl")
print(f"\nBest model ({best_model_name}) saved to models/flood_best_model.pkl")
print("Label encoder saved to models/label_encoder.pkl")
print("All visualizations saved to the models/ directory")